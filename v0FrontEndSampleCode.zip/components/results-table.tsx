import { ExternalLink } from "lucide-react"

interface Result {
  id: string
  name: string
  title: string
  website: string
  email: string
  phone: string
  region: string
  industry: string
}

interface ResultsTableProps {
  results: Result[]
}

export default function ResultsTable({ results }: ResultsTableProps) {
  return (
    <div className="w-full overflow-x-auto">
      <table className="w-full min-w-[800px]">
        <thead>
          <tr className="border-b border-gray-100">
            <th className="py-3 px-4 text-left font-medium text-sm text-gray-500">Name</th>
            <th className="py-3 px-4 text-left font-medium text-sm text-gray-500">Title</th>
            <th className="py-3 px-4 text-left font-medium text-sm text-gray-500">Website</th>
            <th className="py-3 px-4 text-left font-medium text-sm text-gray-500">Email</th>
            <th className="py-3 px-4 text-left font-medium text-sm text-gray-500">Phone</th>
            <th className="py-3 px-4 text-left font-medium text-sm text-gray-500">Region</th>
            <th className="py-3 px-4 text-left font-medium text-sm text-gray-500">Industry</th>
          </tr>
        </thead>
        <tbody>
          {results.map((result) => (
            <tr key={result.id} className="border-b border-gray-50 hover:bg-gray-50">
              <td className="py-4 px-4 font-medium">{result.name}</td>
              <td className="py-4 px-4 text-gray-600">{result.title}</td>
              <td className="py-4 px-4">
                {result.website ? (
                  <a
                    href={`https://${result.website}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-gray-600 hover:text-black flex items-center gap-1"
                  >
                    {result.website}
                    <ExternalLink size={14} />
                  </a>
                ) : (
                  <span className="text-gray-400">—</span>
                )}
              </td>
              <td className="py-4 px-4">
                {result.email ? (
                  <a href={`mailto:${result.email}`} className="text-gray-600 hover:text-black">
                    {result.email}
                  </a>
                ) : (
                  <span className="text-gray-400">—</span>
                )}
              </td>
              <td className="py-4 px-4">
                {result.phone ? (
                  <a href={`tel:${result.phone}`} className="text-gray-600 hover:text-black">
                    {result.phone}
                  </a>
                ) : (
                  <span className="text-gray-400">—</span>
                )}
              </td>
              <td className="py-4 px-4 text-gray-600">{result.region}</td>
              <td className="py-4 px-4 text-gray-600">{result.industry}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
