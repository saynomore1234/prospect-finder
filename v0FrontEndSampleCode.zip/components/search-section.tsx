"use client"

import type React from "react"

import { Search } from "lucide-react"

interface SearchSectionProps {
  searchQuery: string
  setSearchQuery: (query: string) => void
  onSearch: () => void
}

export default function SearchSection({ searchQuery, setSearchQuery, onSearch }: SearchSectionProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      onSearch()
    }
  }

  return (
    <div className="w-full mb-8">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search for companies, industries, or keywords..."
            className="w-full py-4 px-5 pl-12 text-lg border border-gray-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-gray-200 transition-all"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
        </div>
        <button
          type="submit"
          disabled={!searchQuery.trim()}
          className="mt-4 w-full py-3 px-4 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Find Prospects
        </button>
      </form>
    </div>
  )
}
