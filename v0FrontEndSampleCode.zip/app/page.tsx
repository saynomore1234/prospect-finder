"use client"

import { useState } from "react"
import SearchSection from "@/components/search-section"
import FiltersSection from "@/components/filters-section"
import ResultsTable from "@/components/results-table"
import { Download } from "lucide-react"

// Sample data for demonstration
const sampleResults = [
  {
    id: "1",
    name: "John Smith",
    title: "Chief Marketing Officer",
    website: "example.com",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    region: "North America",
    industry: "Technology",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    title: "VP of Sales",
    website: "acmecorp.com",
    email: "sarah@acmecorp.com",
    phone: "",
    region: "Europe",
    industry: "Manufacturing",
  },
  {
    id: "3",
    name: "Michael Chen",
    title: "Director of Operations",
    website: "globalinc.com",
    email: "mchen@globalinc.com",
    phone: "+86 123 456 7890",
    region: "Asia",
    industry: "Logistics",
  },
  {
    id: "4",
    name: "Emma Williams",
    title: "Head of Product",
    website: "techstartup.io",
    email: "",
    phone: "+44 20 1234 5678",
    region: "Europe",
    industry: "Technology",
  },
  {
    id: "5",
    name: "Carlos Rodriguez",
    title: "Business Development Manager",
    website: "innovate.co",
    email: "carlos@innovate.co",
    phone: "",
    region: "South America",
    industry: "Consulting",
  },
]

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filters, setFilters] = useState({
    region: "",
    industry: "",
    jobTitle: "",
  })
  const [results, setResults] = useState<any[] | null>(null)

  const handleSearch = () => {
    // In a real app, this would make an API call with searchQuery and filters
    // For demo purposes, we'll just set the sample results after a short delay
    setTimeout(() => {
      setResults(sampleResults)
    }, 500)
  }

  const handleExport = () => {
    // In a real app, this would trigger a CSV/Excel export
    alert("Exporting results...")
  }

  const handleReset = () => {
    setResults(null)
    setSearchQuery("")
    setFilters({
      region: "",
      industry: "",
      jobTitle: "",
    })
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <header className="w-full py-6 px-8 flex justify-between items-center border-b border-gray-100">
        <div className="font-semibold text-xl tracking-tight">ProspectFinder</div>
        <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
          {/* Placeholder for future dark/light mode toggle */}
        </div>
      </header>

      <main className="flex-1 flex flex-col px-4 sm:px-8 py-8 max-w-7xl mx-auto w-full">
        {!results ? (
          <div className="flex-1 flex flex-col items-center justify-center max-w-3xl mx-auto w-full">
            <h1 className="text-3xl font-bold mb-12 text-center">Find Your Next Prospects</h1>

            <SearchSection searchQuery={searchQuery} setSearchQuery={setSearchQuery} onSearch={handleSearch} />

            <FiltersSection filters={filters} setFilters={setFilters} />
          </div>
        ) : (
          <div className="w-full">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h2 className="text-2xl font-semibold">Results</h2>
                <p className="text-gray-500 text-sm mt-1">
                  Found {results.length} prospects for "{searchQuery}"
                </p>
              </div>

              <div className="flex gap-4">
                <button
                  onClick={handleReset}
                  className="px-4 py-2 text-sm border border-gray-200 rounded-md hover:bg-gray-50 transition-colors"
                >
                  New Search
                </button>
                <button
                  onClick={handleExport}
                  className="px-4 py-2 text-sm bg-black text-white rounded-md hover:bg-gray-800 transition-colors flex items-center gap-2"
                >
                  <Download size={16} />
                  Export
                </button>
              </div>
            </div>

            <ResultsTable results={results} />
          </div>
        )}
      </main>

      <footer className="py-6 px-8 border-t border-gray-100 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} ProspectFinder. All rights reserved.
      </footer>
    </div>
  )
}
